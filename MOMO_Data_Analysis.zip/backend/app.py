from flask import Flask, jsonify
from backend.database import init_db, insert_transactions, get_all_transactions
from backend.sms_parser import parse_sms_xml

app = Flask(__name__)

@app.route('/api/transactions', methods=['GET'])
def api_get_transactions():
    # Return all transactions as JSON
    return jsonify(get_all_transactions()), 200

def main():
    init_db()
    transactions = parse_sms_xml('data/modified_sms_v2.xml')
    insert_transactions(transactions)
    app.run(debug=True)

if __name__ == '__main__':
    main()
