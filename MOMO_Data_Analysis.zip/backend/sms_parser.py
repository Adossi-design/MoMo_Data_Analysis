import xml.etree.ElementTree as ET
from datetime import datetime
import re

def parse_sms_xml(file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    transactions = []

    for sms in root.findall('sms'):
        body = sms.get('body', '')
        date_ms = int(sms.get('date', '0'))
        date = datetime.fromtimestamp(date_ms / 1000).strftime('%Y-%m-%d %H:%M:%S')

        txn = {'date': date, 'message': body, 'type': 'Other', 'amount': 0, 'phone_number': 'Unknown'}

        # Determine transaction type
        if 'received' in body.lower():
            txn['type'] = 'Received'
        elif 'sent' in body.lower():
            txn['type'] = 'Sent'

        # Extract amount
        amount_match = re.search(r'UGX\s*([\d,]+)', body)
        if amount_match:
            txn['amount'] = int(amount_match.group(1).replace(',', ''))

        # Extract phone number
        phone_match = re.search(r'from\s+(\d+)', body) or re.search(r'to\s+(\d+)', body)
        if phone_match:
            txn['phone_number'] = phone_match.group(1)

        transactions.append(txn)

    return transactions
