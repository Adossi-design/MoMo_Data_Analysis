import sqlite3

DB_PATH = 'database/momo.db'

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone_number TEXT,
            amount INTEGER,
            type TEXT,
            date TEXT,
            message TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_transactions(transactions):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    for txn in transactions:
        c.execute('INSERT INTO transactions (phone_number, amount, type, date, message) VALUES (?, ?, ?, ?, ?)',
                  (txn['phone_number'], txn['amount'], txn['type'], txn['date'], txn['message']))
    conn.commit()
    conn.close()

def get_all_transactions():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('SELECT phone_number, amount, type, date FROM transactions')
    rows = c.fetchall()
    conn.close()

    return [{'phone_number': r[0], 'amount': r[1], 'type': r[2], 'date': r[3]} for r in rows]
