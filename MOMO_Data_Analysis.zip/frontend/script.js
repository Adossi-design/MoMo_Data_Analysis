async function fetchTransactions() {
    const res = await fetch('/api/transactions');
    const data = await res.json();
    const tbody = document.querySelector('#transactions-table tbody');
    tbody.innerHTML = '';

    data.forEach(txn => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${txn.phone_number}</td>
            <td>${txn.amount}</td>
            <td>${txn.type}</td>
            <td>${txn.date}</td>
        `;
        tbody.appendChild(tr);
    });
}
fetchTransactions();
